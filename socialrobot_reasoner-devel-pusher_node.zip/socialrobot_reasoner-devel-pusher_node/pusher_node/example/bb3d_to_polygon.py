#!/usr/bin/env python
import itertools
import numpy as np
from geometry_msgs import msg as geo_msg


def interpolate_point32(A, B, interval=0.1):
    dist_x = B[0] - A[0]
    dist_y = B[1] - A[1]
    num = int(np.sqrt(dist_x**2 + dist_y**2) / interval) + 1
    dx = dist_x / num
    dy = dist_y / num
    return [geo_msg.Point32(A[0] + dx * i, A[1] + dy * i, 0.0) for i in range(num)]


def bb3d_to_polygon(bb3d):
    """
    A-----------B
    |     ^ X   |
    | Y <-+     |(length)
    |           |
    D--(width)--C
    """
    # Center
    x = bb3d.center.position.x
    y = bb3d.center.position.y
    length = bb3d.size.x
    width = bb3d.size.y
    quat = bb3d.center.orientation
    # X-axis heading from Quaternion
    # This equation is the X-axis direction (xx, xy, xz) from the rotation matrix R
    half_xx = 0.5 - (quat.y * quat.y + quat.z * quat.z)
    half_xy = quat.x * quat.y + quat.z * quat.w
    heading = np.arctan2(half_xy, half_xx)
    # Unit vectors
    x_unit = (np.cos(heading), np.sin(heading))
    y_unit = (-x_unit[1], x_unit[0])
    x_vec = (length * x_unit[0], length * x_unit[1])
    y_vec = (width * y_unit[0], width * y_unit[1])
    # Polygon vertices
    A = (x + 0.5 * x_vec[0] + 0.5 * y_vec[0], y + 0.5 * x_vec[1] + 0.5 * y_vec[1])
    B = (A[0] - y_vec[0], A[1] - y_vec[1])
    C = (B[0] - x_vec[0], B[1] - x_vec[1])
    D = (A[0] - x_vec[0], A[1] - x_vec[1])
    # Line segments
    line_segments = [(A, B), (B, C), (C, D), (D, A)]
    # Polygon.points (geometry_msgs/Point32)
    return list(itertools.chain.from_iterable(
        [interpolate_point32(a, b) for a, b in line_segments]))


if __name__=="__main__":
    polygon = geo_msg.Polygon()

    obj_A = None  # bb3d
    obj_B = None  # bb3d

    polygon.points.extend(bb3d_to_polygon(obj_A))
    polygon.points.extend(bb3d_to_polygon(obj_B))
