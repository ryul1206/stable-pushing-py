
def mobile_plan(pose2d_robot, pose2d_behind_of_chair, dots_boundary, dots_chair):
    """ {/map} Plan for object, use object path """
    # 의자 기준으로 플래닝하기 때문에, 의자 위치에 로봇크기 입력.
    req = PlanePushingRequest()
    req.robot_width_meter = 0.001  # dummy
    req.object_width_meter = ROBOT_WIDTH
    # Start and goal (/map frame)
    req.object_start = pose2d_robot
    req.object_goal = pose2d_behind_of_chair
    req.ignore_goal_orientation = False
    req.motion_model = req.OMNI
    # geometry_msgs/Point32[] req.obstacles : 장애물들 폴리곤 추가.
    req.obstacles.points.extend(dots_chair)
    req.obstacles.points.extend(dots_boundary)
    return req
