#!/usr/bin/env python
import numpy as np
import rospy
from tf import transformations

# move base
from trajectory_msgs.msg import *
from sensor_msgs.msg import *
from vision_msgs.msg import *
from visualization_msgs.msg import *
from geometry_msgs.msg import *
from std_msgs.msg import *
from nav_msgs.msg import *
from socialrobot_msgs import msg as social_robot_msg

# pure_hybrid_astar
from pusher_node.srv import PlanePushing, PlanePushingRequest, PlanePushingResponse
from bb3d_to_polygon import bb3d_to_polygon

class PlanTest():

    def __init__(self):
        self.detected_objects = None
        self.objects_from_robot = None
        self.objects_from_camera = None
        self.marker_arr = MarkerArray()
        self.bbox_arr = MarkerArray()

        self.srv_name = "/pusher_node/find_path"
        rospy.wait_for_service(self.srv_name)

        # pubisher
        self.path_pub = rospy.Publisher('/mobile_path', Path, queue_size=10)
        self.pose_pub = rospy.Publisher('/mobile_pose', PoseArray, queue_size=10)
        self.obstacle_pub = rospy.Publisher('/obstacles', MarkerArray, queue_size=10)
        self.bbox_pub = rospy.Publisher('/bbox', MarkerArray, queue_size=10)


    def create_boundingbox(self, trans_vec, rot_vec, size):
        '''create bounding box ROS msg'''

        bb3d = BoundingBox3D()
        bb3d.center.position.x = trans_vec[0]
        bb3d.center.position.y = trans_vec[1]
        bb3d.center.position.z = trans_vec[2]
        bb3d.center.orientation.x = rot_vec[0]
        bb3d.center.orientation.y = rot_vec[1]
        bb3d.center.orientation.z = rot_vec[2]
        bb3d.center.orientation.w = rot_vec[3]
        bb3d.size.x = size[0]
        bb3d.size.y = size[1]
        bb3d.size.z = size[2]
        return bb3d

    def load_points(self):
        pt_list = []

        pt = Point32()
        pt.x = 0.8343946034273562
        pt.y = -0.7969666711359984
        pt.z = 0.0
        pt_list.append(pt)

        pt = Point32()
        pt.x = 1.0150208642727776
        pt.y = -0.6641357538222817
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.9275374634487045
        pt.y = -0.6658400367373419
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.8400540626246313
        pt.y = -0.667544319652402
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.7525706618005583
        pt.y = -0.6692486025674622
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.6650872609764852
        pt.y = -0.6709528854825224
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.577603860152412
        pt.y = -0.6726571683975826
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.49012045932833903
        pt.y = -0.6743614513126428
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.4026370585042659
        pt.y = -0.6760657342277029
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.31515365768019277
        pt.y = -0.6777700171427631
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.3133557328467227
        pt.y = -0.5854798360536311
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.3115578080132526
        pt.y = -0.49318965496449896
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.30975988317978254
        pt.y = -0.4008994738753669
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.30796195834631246
        pt.y = -0.30860929278623483
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.3061640335128424
        pt.y = -0.21631911169710277
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.3043661086793723
        pt.y = -0.12402893060797071
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.3025681838459023
        pt.y = -0.031738749518838705
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.3007702590124322
        pt.y = 0.06055143157029341
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.29897233417896213
        pt.y = 0.15284161265942553
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.29717440934549205
        pt.y = 0.24513179374855754
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.295376484512022
        pt.y = 0.33742197483768954
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.2935785596785519
        pt.y = 0.42971215592682166
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.2917806348450818
        pt.y = 0.5220023370159538
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.3792640356691549
        pt.y = 0.523706619931014
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.46674743649322803
        pt.y = 0.5254109028460741
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.554230837317301
        pt.y = 0.5271151857611343
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.6417142381413743
        pt.y = 0.5288194686761944
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.7291976389654473
        pt.y = 0.5305237515912546
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.8166810397895203
        pt.y = 0.5322280345063148
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.9041644406135936
        pt.y = 0.5339323174213749
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.9916478414376667
        pt.y = 0.5356366003364351
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.9934457662711368
        pt.y = 0.44334641924730306
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.9952436911046069
        pt.y = 0.351056238158171
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.9970416159380769
        pt.y = 0.25876605706903894
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.998839540771547
        pt.y = 0.16647587597990687
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 1.000637465605017
        pt.y = 0.07418569489077481
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 1.002435390438487
        pt.y = -0.01810448619835725
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 1.0042333152719571
        pt.y = -0.11039466728748926
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 1.0060312401054272
        pt.y = -0.20268484837662137
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 1.0078291649388973
        pt.y = -0.2949750294657535
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 1.0096270897723674
        pt.y = -0.3872652105548855
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 1.0114250146058374
        pt.y = -0.4795553916440175
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 1.0132229394393075
        pt.y = -0.5718455727331496
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.666094340318814
        pt.y = -1.3228725129934518
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.5672059905180804
        pt.y = -1.3275729676190982
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.4683176407173469
        pt.y = -1.3322734222447448
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.36942929091661336
        pt.y = -1.3369738768703912
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.2705409411158798
        pt.y = -1.3416743314960378
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.17165259131514626
        pt.y = -1.3463747861216842
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.17630556660113975
        pt.y = -1.4442642637022083
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.18095854188713323
        pt.y = -1.5421537412827324
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.18561151717312668
        pt.y = -1.6400432188632565
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.19026449245912017
        pt.y = -1.7379326964437807
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.19491746774511365
        pt.y = -1.8358221740243048
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.2938058175458472
        pt.y = -1.8311217193986584
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.39269416734658075
        pt.y = -1.8264212647730118
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.49158251714731427
        pt.y = -1.8217208101473654
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.5904708669480478
        pt.y = -1.8170203555217188
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.6893592167487814
        pt.y = -1.8123199008960724
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.6847062414627879
        pt.y = -1.7144304233155483
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.6800532661767944
        pt.y = -1.6165409457350242
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.675400290890801
        pt.y = -1.5186514681545
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.6707473156048075
        pt.y = -1.420761990573976
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.7326651269379436
        pt.y = -1.3675826958710826
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.7780385887231676
        pt.y = -1.279592645492504
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.8234120505083916
        pt.y = -1.1916025951139253
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.8687855122936156
        pt.y = -1.1036125447353466
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.9141589740788396
        pt.y = -1.0156224943567678
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.9595324358640636
        pt.y = -0.9276324439781891
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.915093016480943
        pt.y = -0.9047165541876719
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.869719554695719
        pt.y = -0.9927066045662507
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.824346092910495
        pt.y = -1.0806966549448294
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.778972631125271
        pt.y = -1.1686867053234082
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.733599169340047
        pt.y = -1.256676755701987
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.688225707554823
        pt.y = -1.3446668060805655
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.9900111600131344
        pt.y = -1.0234321505779593
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -1.003762527158628
        pt.y = -0.9967649437945364
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.9371016205071717
        pt.y = -0.962390192473169
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.9233502533616782
        pt.y = -0.989057399256592
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.7326529900728942
        pt.y = -1.3676231275657473
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.7780264518581181
        pt.y = -1.2796330771871687
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.8233999136433422
        pt.y = -1.19164302680859
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.8687733754285661
        pt.y = -1.1036529764300114
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.9141468372137902
        pt.y = -1.0156629260514325
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.9595202989990141
        pt.y = -0.9276728756728538
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.9150808796158936
        pt.y = -0.9047569858823367
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.8697074178306696
        pt.y = -0.9927470362609154
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.8243339560454456
        pt.y = -1.080737086639494
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.7789604942602216
        pt.y = -1.168727137018073
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.7335870324749976
        pt.y = -1.2567171873966516
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = -0.6882135706897736
        pt.y = -1.3447072377752303
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.1915604796225313
        pt.y = -0.08858101745916552
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.1686772241125863
        pt.y = -0.14941979051813326
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.10783845105361857
        pt.y = -0.12653653500818823
        pt.z = 0.0

        pt_list.append(pt)
        pt = Point32()
        pt.x = 0.13072170656356358
        pt.y = -0.0656977619492205
        pt.z = 0.0
        pt_list.append(pt)


        return pt_list

    def load_objects(self):
        object_list = []
        self.dynamic_obj = {
                            'obj_fridge': self.create_boundingbox([0.746047016395, -0.864593112785, 0.842750678714],
                                                                [0,0,0.510406041818,0.85993352794],
                                                                [0.49, 0.495, 1.36]),
                            'obj_table': self.create_boundingbox([2.37985486709, 0.0188299027122, 0.362964673772],
                                                                [0,0,-0.842362119656,0.538911921717],
                                                                [1.2, 0.7, 0.73]),
                            'obj_chair': self.create_boundingbox([-0.583961725235, 1.45885896683, 0.447950273752],
                                                                [0,0, -0.976081669331, -0.217404514551],
                                                                [0.45001962781, 0.400061368942, 0.90878623724]),
                            'obj_fridge_bottom_door': self.create_boundingbox([0.585743353296, -0.294093852356, 0.627700482046],
                                                                [0,0,0.999927301671,-0.0120578344899],
                                                                [0.05, 0.495, 0.92]),
                           }
        obj_list = self.dynamic_obj.keys()
        for id in obj_list:
            object_list.append(self.dynamic_obj[id])
        return object_list

    def get_motion(self):
        ## load objects
        obstacles = self.load_objects()
        points = self.load_points()

        return self.request(obstacles=obstacles, points=points)

    def create_markers(self, polygon):

        for i,pt in enumerate(polygon.points):
            marker = Marker()
            marker.header.stamp = rospy.Time.now()
            marker.header.frame_id = '/base_footprint'
            marker.ns = 'obstacle'
            marker.id = i
            marker.type = Marker.SPHERE
            marker.action = Marker.MODIFY
            marker.scale.x = 0.02
            marker.scale.y = 0.02
            marker.scale.z = 0.02
            marker.color.a = 1.0
            marker.color.r = 1.0
            marker.color.g = 1.0
            marker.color.b = 1.0
            marker.lifetime = rospy.Duration(0)
            marker.pose.orientation.w = 1.0
            marker.pose.position.x = pt.x
            marker.pose.position.y = pt.y
            marker.pose.position.z = pt.z
            self.marker_arr.markers.append(marker)

    def create_bbox(self, obstacles):

        for i,bbox in enumerate(obstacles):
            marker = Marker()
            marker.header.stamp = rospy.Time.now()
            marker.header.frame_id = '/base_footprint'
            marker.ns = 'test'
            marker.id = i
            marker.type = Marker.CUBE
            marker.action = Marker.MODIFY
            marker.scale.x = bbox.size.x
            marker.scale.y = bbox.size.y
            marker.scale.z = bbox.size.z
            marker.color.a = 1.0
            marker.color.r = 0.0
            marker.color.g = 1.0
            marker.color.b = 0.0
            marker.lifetime = rospy.Duration(0)
            marker.pose = bbox.center
            self.bbox_arr.markers.append(marker)

    def publish_obstacles(self):
        self.obstacle_pub.publish(self.marker_arr)
        self.bbox_pub.publish(self.bbox_arr)
        return

    def request(self, obstacles=None, points=None):
        req = PlanePushingRequest()
        req.robot_width_meter = 0.001  # dummy
        req.object_width_meter = 0.50  # ROBOT_WIDTH
        # Start and goal (/map frame)
        req.object_start = Pose2D(x=0.0, y=0.0, theta=0.0)

        # goal sample 1
        theta = transformations.euler_from_quaternion([0.0, 
                                                        0.0, 
                                                0.859933535481, 
                                                        0.510406029112])[2]
        req.object_goal = Pose2D(x=1.15095396402, 
                                y=-0.381491060651, 
                                theta=theta)
        
        # # goal sample 2
        # theta = transformations.euler_from_quaternion([0.0, 
        #                                                 0.0, 
        #                                         0.215115773, 
        #                                                 0.976588554206])[2]
        # req.object_goal = Pose2D(x=1.79432830958, 
        #                         y=0.346141361217, 
        #                         theta=theta)

        req.ignore_goal_orientation = False
        req.motion_model = req.OMNI

        obstacles = None
        if obstacles:
            polygon = Polygon()

            for obj in obstacles:
                polygon.points.extend(bb3d_to_polygon(obj))
            req.obstacles = polygon
            self.create_bbox(obstacles)
            self.create_markers(polygon)
        elif points:
            polygon = Polygon()
            polygon.points = points
            req.obstacles = polygon
            self.create_markers(polygon)

        iter=0
        while(not rospy.is_shutdown() and iter<100000):
            self.publish_obstacles()
            iter+=1

        try:
            pusher_proxy = rospy.ServiceProxy(self.srv_name, PlanePushing)
            resp = pusher_proxy(req)
            return resp
        except rospy.ServiceException as e:
            print("Service call failed: %s" % e)
            return PlanePushingResponse()


if __name__ == "__main__":
    rospy.init_node("hybrid_astar_example")

    planner = PlanTest()
    res = planner.get_motion()

    # publish results
    iter=0
    while(not rospy.is_shutdown() and iter<100):
        planner.path_pub.publish(res.object_path)
        iter+=1